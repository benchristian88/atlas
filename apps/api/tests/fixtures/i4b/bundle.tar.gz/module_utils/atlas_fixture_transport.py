# SPDX-License-Identifier: Apache-2.0
"""Only tests import this module. Never included in a normal candidate bundle."""
from copy import deepcopy
import json
from pathlib import Path
import time
from urllib.parse import parse_qs, urlsplit

from ansible.module_utils.atlas_transport import PinnedAdapter

FIXTURES = Path(__file__).parent / 'fixtures/proxmox'


def fixture(scenario='complete'):
    data = json.loads('{\n  "permissions": {\n    "/": {"Sys.Audit": 1},\n    "/access": {"Sys.Audit": 1},\n    "/nodes": {"Sys.Audit": 1},\n    "/vms": {"VM.Audit": 1},\n    "/storage": {"Datastore.Audit": 1},\n    "/sdn/zones/localnetwork": {"SDN.Audit": 1}\n  },\n  "acl": [{"path": "/", "type": "user", "ugid": "fixture-account", "roleid": "FixtureAudit", "propagate": 1}],\n  "responses": {\n    "/version": {"version": "9.2.11"},\n    "/cluster/status": [{"type": "cluster", "name": "fixture-cluster", "quorate": 1}, {"type": "node", "name": "node-a", "id": "node/node-a", "nodeid": 1, "online": 1}, {"type": "node", "name": "node-b", "id": "node/node-b", "nodeid": 2, "online": 1}],\n    "/nodes": [{"node": "node-a", "status": "online"}, {"node": "node-b", "status": "online"}],\n    "/cluster/resources?type=vm": [{"vmid": 100, "node": "node-a", "type": "qemu", "name": "fixture-vm", "status": "running"}, {"vmid": 101, "node": "node-b", "type": "qemu", "name": "fixture-template", "status": "stopped", "template": 1}, {"vmid": 102, "node": "node-a", "type": "lxc", "name": "fixture-container", "status": "running"}],\n    "/storage": [{"storage": "shared", "type": "nfs", "shared": 1}, {"storage": "local", "type": "dir", "shared": 0}],\n    "/nodes/node-a/storage": [{"storage": "shared", "type": "nfs", "shared": 1, "active": 1}, {"storage": "local", "type": "dir", "shared": 0, "active": 1, "total": 100000, "avail": 60000}],\n    "/nodes/node-b/storage": [{"storage": "shared", "type": "nfs", "shared": 1, "active": 1}, {"storage": "local", "type": "dir", "shared": 0, "active": 1, "total": 200000, "avail": 90000}],\n    "/nodes/node-a/network": [{"iface": "vmbr0", "type": "bridge", "active": 1, "bridge_vlan_aware": 1, "cidr": "10.20.0.1/24", "comments": "ignored"}],\n    "/nodes/node-b/network": [{"iface": "vmbr0", "type": "bridge", "active": 1, "bridge_vlan_aware": 1, "cidr": "10.20.0.2/24"}],\n    "/nodes/node-a/qemu": [{"vmid": 100, "name": "fixture-vm", "status": "running"}],\n    "/nodes/node-a/lxc": [{"vmid": 102, "name": "fixture-container", "status": "running"}],\n    "/nodes/node-b/qemu": [{"vmid": 101, "name": "fixture-template", "status": "stopped", "template": 1}],\n    "/nodes/node-b/lxc": [],\n    "/nodes/node-a/qemu/100/config?current=1": {"scsi0": "shared:vm-100-disk-0,size=8G", "net0": "virtio=02:00:00:00:00:01,bridge=vmbr0", "description": "ignored arbitrary description", "args": "ignored command", "unused0": "local:unused"},\n    "/nodes/node-b/qemu/101/config?current=1": {"scsi0": "local:vm-101-disk-0,size=8G", "net0": "virtio=02:00:00:00:00:01,bridge=vmbr0,tag=22"},\n    "/nodes/node-a/lxc/102/config?current=1": {"rootfs": "local:subvol-102-disk-0,size=8G", "net0": "name=eth0,hwaddr=02:00:00:00:00:01,bridge=vmbr0,ip=10.20.0.10/24", "mp0": "/mnt/private,mp=/private", "description": "ignored notes"}\n  },\n  "changes": {},\n  "failures": {}\n}\n')
    changes = json.loads('{\n  "complete": {},\n  "standalone": {"standalone": true},\n  "empty_authorized": {"standalone": true, "empty_guests": true},\n  "empty_unproven": {"standalone": true, "empty_guests": true, "unproven": true},\n  "permission_filtered": {"denied": "/vms/999"},\n  "acl_audit_missing": {"acl_audit_missing": true},\n  "offline": {"offline": "node-b"},\n  "source_failure": {"failures": {"/cluster/resources?type=vm": 500}},\n  "storage_failure": {"failures": {"/nodes/node-b/storage": 403}},\n  "config_failure": {"failures": {"/nodes/node-a/qemu/100/config?current=1": 403}},\n  "pending": {"changes": {"/nodes/node-a/network": "staged configuration"}},\n  "malformed": {"malformed": true},\n  "limits": {"limits": true},\n  "renamed": {"rename": true},\n  "migrated": {"migration": true},\n  "slow": {"slow": true},\n  "malformed_aip": {"malformed_aip": true}\n}\n')[scenario]
    responses = data['responses']
    data['failures'].update(changes.get('failures', {}))
    data['changes'].update(changes.get('changes', {}))
    if changes.get('denied'):
        path = changes['denied']
        data['acl'].append({'path': path, 'roleid': 'NoAccess', 'type': 'user', 'ugid': 'fixture-account', 'propagate': 1})
        data['permissions'][path] = {}
    if changes.get('acl_audit_missing'):
        data['permissions']['/access'] = {}
    if changes.get('unproven'):
        data['permissions']['/vms'] = {}
    if changes.get('standalone'):
        responses['/cluster/status'] = [row for row in responses['/cluster/status'] if row.get('name') == 'node-a']
        responses['/nodes'] = responses['/nodes'][:1]
        responses['/cluster/resources?type=vm'] = [row for row in responses['/cluster/resources?type=vm'] if row['node'] == 'node-a']
    if changes.get('empty_guests'):
        responses['/cluster/resources?type=vm'] = []
        responses['/nodes/node-a/qemu'] = responses['/nodes/node-a/lxc'] = []
    if changes.get('offline'):
        for row in responses['/nodes']:
            if row['node'] == changes['offline']: row['status'] = 'offline'
        for row in responses['/cluster/status']:
            if row.get('name') == changes['offline']: row['online'] = 0
    if changes.get('malformed'):
        responses['/nodes/node-a/qemu/100/config?current=1']['net0'] = 'invalid'
    if changes.get('limits'):
        responses['/nodes'] = [{'node': f'node-{index}', 'status': 'online'} for index in range(33)]
    if changes.get('rename'):
        responses['/cluster/resources?type=vm'][0]['name'] = 'renamed-vm'
        responses['/nodes/node-a/qemu'][0]['name'] = 'renamed-vm'
    if changes.get('migration'):
        responses['/cluster/resources?type=vm'][0]['node'] = 'node-b'
        responses['/nodes/node-b/qemu'].append(responses['/nodes/node-a/qemu'].pop())
        responses['/nodes/node-b/qemu/100/config?current=1'] = responses.pop('/nodes/node-a/qemu/100/config?current=1')
    data['slow'] = changes.get('slow', False)
    return data


class FixtureResponse:
    def __init__(self, data, path):
        self.status = data['failures'].get(path, 200)
        if path.startswith('/access/permissions'):
            query = parse_qs(urlsplit(path).query)
            if query.get('path'):
                key = query['path'][0]
                prefixes = [p for p in data['permissions'] if key == p or key.startswith(p.rstrip('/') + '/')]
                selected = max(prefixes, key=len, default=None)
                value = {key: deepcopy(data['permissions'][selected]) if selected else {}}
            else:
                # Real API drops zero-permission paths: exercise hidden NoAccess.
                value = {key: grants for key, grants in data['permissions'].items() if grants}
        elif path == '/access/acl':
            value = deepcopy(data['acl'])
        else:
            value = deepcopy(data['responses'][path])
        self.raw = json.dumps({'data': value, 'changes': data['changes'].get(path)}).encode()
        self.offset = 0

    def getheader(self, name, default=None):
        return str(len(self.raw)) if name == 'Content-Length' else default

    def read(self, maximum):
        result = self.raw[self.offset:self.offset + maximum]
        self.offset += len(result)
        return result


def adapter_factory(data):
    calls = []
    class Connection:
        def __init__(self, host, port, address, context, fingerprint, timeout):
            assert address == '192.168.50.2'
            self.path = None
        def request(self, method, path, headers):
            assert method == 'GET' and headers['Authorization'].startswith('PVEAPIToken=')
            self.path = path.removeprefix('/api2/json')
            calls.append(self.path)
        def getresponse(self):
            if data.get('slow') and self.path == '/cluster/status':
                (Path.cwd().parent / 'fixture.pid').write_text(str(__import__('os').getpid()))
                time.sleep(120)
            return FixtureResponse(data, self.path)
        def close(self): pass
    def build(config, deadline):
        return PinnedAdapter(config, deadline, resolver=lambda *a, **kw: [(2, 1, 6, '', ('192.168.50.2', 8006))], connection_factory=Connection)
    build.calls = calls
    return build


def fixture_adapter(config, deadline):
    scenario = config.get('fixture_scenario', 'complete')
    if scenario == 'malformed_aip':
        from ansible.module_utils import atlas_discovery
        original = atlas_discovery.stream
        def corrupt(*args):
            messages = original(*args)
            messages[0]['customer_id'] = 'forbidden'
            return messages
        atlas_discovery.stream = corrupt
    return adapter_factory(fixture(scenario))(config, deadline)
