# SPDX-License-Identifier: Apache-2.0
# TEST ONLY: production does not include a fixture adapter or scenario input.
from ansible.module_utils.atlas_discovery import main
from ansible.module_utils.atlas_fixture_transport import fixture_adapter
if __name__ == '__main__':
    main(adapter_factory=fixture_adapter)
